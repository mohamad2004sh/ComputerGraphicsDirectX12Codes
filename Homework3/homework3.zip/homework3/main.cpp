#include <iostream>
#include <cctype>
#include <string>
using namespace std;
void quantification(int a[4][4], int b[4][4]);
void sum(int a[4][4], int b[4][4]);
void subtraction(int a[4][4], int b[4][4]);
void multiplication(int a[4][4], int b[4][4]);
void transpose(int a[4][4]);
int main()
{
    int a[4][4], b[4][4];
    quantification(a,b);
    while (true) {
        int o;
        cout << "1.sum\n"
                "2.subtraction\n"
                "3.multiplication\n"
                "4.transpose(a)\n"
                "5.transpose(b)\n"
                "6.end\n"
                "Enter your order number:\n";
        cin >> o;
        if (o == 6) { break; }
        switch (o) {
            case 1:
                sum(a, b);
                break;
            case 2:
                subtraction(a, b);
                break;
            case 3:
                multiplication(a, b);
                break;
            case 4:
                transpose(a);
                break;
            case 5:
                transpose(b);
                break;

        }

        cout << "end";
    }
}
void pmatrix(int c [4][4]) {
    for (int i = 0; i < 4; i++) {
        for (int j = 0; j < 4; j++) {
            cout <<c[i][j] ;
        }
        cout << endl <<"\n";
    }
}
void quantification(int a[4][4], int b[4][4]) {
    for (int i = 0; i < 4; i++) {
        for (int j = 0; j < 4; j++) {
            cout << "Enter A[" << i+1 << "][" << j+1 << "] : ";
            cin >> a[i][j];

        }

    }
    for (int i = 0; i < 4; i++) {
        for (int j = 0; j < 4; j++) {
            cout << "Enter B[" << i+1 << "][" << j+1 << "] : ";
            cin >> b[i][j];

        }

    }
}
void sum(int a[4][4], int b[4][4]) {
    int c[4][4];
    for (int i = 0; i < 4; i++) {
        for (int j = 0; j < 4; j++) {
            c[i][j]=a[i][j] + b[i][j];
        }

    }
    pmatrix(c);
}
void subtraction(int a[4][4], int b[4][4]) {
    int c[4][4];
    for (int i = 0; i < 4; i++) {
        for (int j = 0; j < 4; j++) {
            c[i][j] = a[i][j] - b[i][j];
        }

    }
    pmatrix(c);
}
void multiplication(int a[4][4], int b[4][4]) {
    int mul[4][4];
    for (int i = 0; i < 4; i++) {
        for (int j = 0; j < 4; j++) {
            mul[i][j] = 0;
            for (int k = 0; k < 4; k++) {
                mul[i][j] += a[i][k] * b[k][j];
            }

        }

    }
    pmatrix(mul);
}
void transpose(int a[4][4]) {
    int Transpose[4][4];
    for (int i = 0; i < 4; i++) {
        for (int j = 0; j < 4; j++) {
            Transpose[i][j] = a[j][i];
        }
    }
    pmatrix(Transpose);
}
